package com.kh.chap01_frame.run;

import com.kh.chap01_frame.view.*;

public class Run {

	public static void main(String[] args) {
		
//		MainFrame1 mf1 = new MainFrame1();
//		mf1.showFrame();
//		
//		new MainFrame2();
		new MainFrame3();
		
	}

}

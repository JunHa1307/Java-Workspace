package com.kh.chap02_component.run;

import com.kh.chap02_component.view.MainFrame;

public class Run {
	public static void main(String[] args) {
		new MainFrame();
	}
}

package com.kh.chap03_event.run;

import com.kh.chap03_event.view.MainFrame;

public class Run {

	public static void main(String[] args) {
		new MainFrame();
	}

}
